# -*- coding: UTF-8 -*-
# if 语句
a = 14
if(a == 1):
    print '1'
elif(a == 2):
    print '2'
elif(a == 3):
    print '3'
else:
    print '4'

# while

count = 0
while(count < 10):
    print 'The count is',count
    count += 1
print 'over'

numbers = [1,2,3,4,5,6,7,8,9]
even = []
odd = []

while(len(numbers)):
    number = numbers.pop()
    if(number % 2 == 0):
        continue
    if(number < 5):
        break
    print('number % 2 != 0 : ' ,number)

while(len(numbers) > 0):  # len() 获取数组长度
    number = numbers.pop() # pop
    if(number % 2 == 0):
        even.append(number)
    else:
        odd.append(number)
print(numbers)
print(even)
print(odd)

# while else
startIndex = 0
while(startIndex < 5):
    print startIndex, 'is less than 5'
    startIndex += 1
else:
    print startIndex, 'is not less than 5'

# for
myname = 'brick'
for letter in myname:
    print letter
fruits = ['appale', 'banana', 'mango']
for fruit in fruits:
    print fruit

for index in range(len(fruits)):
    print fruits[index]

for index in range(10,36):
    print index
else:
    print 'for over'

# pass

for letter in 'Python':
    if letter == 'h':
        pass
        print 'it is pass block'
    print 'cur letter is : ', letter


