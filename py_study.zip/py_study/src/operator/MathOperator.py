# -*- coding: UTF-8 -*-

# 这里只练习与java有区别的运算符
# 赋值运算符对所有算术运算符都是多一个=

# x 的 y 次幂
a = 3
b = 2
c = 0

c = a ** b
print c

# 取整除，返回商的整数部分
c = a // b
print c