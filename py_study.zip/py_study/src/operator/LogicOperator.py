# -*- coding: UTF-8 -*-

# 逻辑运算符
a = 1
b = 1
c = 0

print a and b, a and c

if ( a and b ):
    print 'a and b', 'true'
else:
    print 'a and b', 'false'

if ( a and c ):
    print 'a and c', 'true'
else:
    print 'a and c', 'false'

print a or b, a or c
print not a, not c