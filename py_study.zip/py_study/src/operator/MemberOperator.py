# -*- coding: UTF-8 -*-

# 成员运算符
xs = [1,2,3,4,5,6]
a = 1
b = 10

c = True
d = False

if(c):
    print c
else:
    print d

print a in xs
print b in xs
print b not in xs

# 身份运算符  is    is not

print a is b
print a is not b
