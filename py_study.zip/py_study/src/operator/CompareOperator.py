# -*- coding: UTF-8 -*-

# 比较运算符没有什么特殊的，表示‘不等’的方式多了一种
a = 1
b = 2
c = 1
print a!=b, a!=c
print a<>b, a<>c  # <>与!= 类似
print a==b, a==c