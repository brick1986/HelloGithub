# -*- coding: UTF-8 -*-

# int(x, base) x是字符串或者数字 base是进制数，默认是十进制

print int()
print int(3)
print int(3.6)
print int('12', 16)
print int('12', 8)

# long(x, base)
a = 1L
print a
print long()
print long(1L)
print long('123')

# float(x)

print float(1)
print float('123')

# str(obj) str() 函数将对象转化为适于人阅读的形式
s = 'brick'
print str(s)
dictArg = {'name': 'brick', 'age': 30}
print str(dictArg)

# repr(obj) repr() 函数将对象转化为供解释器读取的形式
print repr(s)
print repr(dictArg)

# eval(expression[, globals[, locals]])
# expression -- 表达式
# globals -- 变量作用域，全局命名空间，如果被提供，则必须是一个字典对象
# locals -- 变量作用域，局部命名空间，如果被提供，可以是任何映射对象
x = 7
x = eval('3 * x')
print x
x = eval('pow(x,2)')
print x

# tuple 元组 tuple() 函数将列表转换为元组
lx = [1,2,3,4]
print lx
print tuple(lx)
print tuple(dictArg)

# list() 方法用于将元组转换为列表
aTuple = (1,2,3,4,5)
print aTuple
print list(aTuple)

# set() 函数创建一个无序不重复元素集，可进行关系测试，删除重复数据，还可以计算交集、差集、并集等
x = set('runoob')
y = set('google')
print x,y
print x & y   #交集
print x | y   #并集
print x - y,y - x  #差集

# dict() 函数用于创建一个字典
print dict(a='a', b='b', c='c')
print dict(zip(['one', 'two', 'three'], [1, 2, 3]))
print dict([('one', 1), ('two', 2), ('three', 3)])

# frozenset() 返回一个冻结的集合，冻结后集合不能再添加或删除任何元素
print frozenset(range(10))
print frozenset('brick')

# chr() 用一个范围在 range（256）内的（就是0～255）整数作参数，返回一个对应的字符
# 返回值是当前整数对应的ascii字符
print chr(100)

# unichr() 函数 和 chr()函数功能基本一样， 只不过是返回 unicode 的字符
print unichr(100)

# ord() 函数是 chr() 函数（对于8位的ASCII字符串）或 unichr() 函数（对于Unicode对象）的配对函数，它以一个字符（长度为1的字符串）作为参数，返回对应的 ASCII 数值，或者 Unicode 数值，如果所给的 Unicode 字符超出了你的 Python 定义范围，则会引发一个 TypeError 的异常。
print ord('b')
print ord('r')
print ord('i')
print ord('c')
print ord('k')

# hex() 函数用于将10进制整数转换成16进制，以字符串形式表示
print hex(16)
print type(hex(255))

# oct() 函数将一个整数转换成8进制字符串
print oct(8)
print oct(16)