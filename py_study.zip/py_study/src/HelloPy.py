# -*- coding: UTF-8 -*-
print("hello, python")

x = "a"
y = "b"
# 换行输出
print x
print y

print "--------------------------"

# 不换行输出
print x,
print y

print x,y

# 字符串

str = 'hello world!'

print str

print str[0]
print str[2:4]  # 不包含上边界
print str[4:]
print str * 2
print str + 'my boy'

print "--------------------------"

# 列表 []
brickInfo = ['brick', 1986, 'man', '78kg', 181]
brickTel = ['China-union', 18611955870]

print brickInfo
brickInfo[0] = 'jacob'
brickInfo.append('handsome')
print brickInfo[0]
print brickInfo[1:3]  # 不包含上边界
print brickTel * 2
print brickInfo + brickTel

# 元组 ()
brickTuple = ('papa', 'son', 'husband', 'brother')
print brickTuple

# 字典 {}
dict = {}
dict['one'] = 'this is 1'
dict[2] = 'this is two'

sondict = {'three': 'this is 3', 4: 'this is four', 'five': 'this is 5'}

print dict['one']
print dict[2]
print sondict
print sondict.keys()
print sondict.values()



